from tkinter import *
from tkinter import ttk, messagebox
import csv
import os
from datetime import datetime

FILENAME = "attendance.csv"
if not os.path.exists(FILENAME):
    with open(FILENAME, "w", newline="") as file:
        writer = csv.writer(file)
        writer.writerow(["USN", "Name", "Date", "Time", "Status"])

class AttendanceApp:
    def __init__(self, root):
        self.root = root
        self.root.title("📘 Student Attendance Management System")
        self.root.geometry("700x500")
        self.root.configure(bg="#eaf6ff")

        title = Label(root, text="📘 Attendance Management System", font=("Helvetica", 20, "bold"), bg="#eaf6ff", fg="#333")
        title.pack(pady=15)

        form_frame = Frame(root, bg="#eaf6ff")
        form_frame.pack(pady=10)

        # USN
        Label(form_frame, text="USN:", font=("Arial", 12), bg="#eaf6ff").grid(row=0, column=0, padx=10, pady=5, sticky=W)
        self.usn_entry = Entry(form_frame, width=30, font=("Arial", 12))
        self.usn_entry.grid(row=0, column=1, padx=10, pady=5)

        # Name
        Label(form_frame, text="Name:", font=("Arial", 12), bg="#eaf6ff").grid(row=1, column=0, padx=10, pady=5, sticky=W)
        self.name_entry = Entry(form_frame, width=30, font=("Arial", 12))
        self.name_entry.grid(row=1, column=1, padx=10, pady=5)

        # Status
        Label(form_frame, text="Status:", font=("Arial", 12), bg="#eaf6ff").grid(row=2, column=0, padx=10, pady=5, sticky=W)
        self.status_var = StringVar()
        self.status_combo = ttk.Combobox(form_frame, textvariable=self.status_var, values=["Present", "Absent"], state="readonly", font=("Arial", 12), width=28)
        self.status_combo.grid(row=2, column=1, padx=10, pady=5)

        # Buttons
        btn_frame = Frame(root, bg="#eaf6ff")
        btn_frame.pack(pady=20)

        Button(btn_frame, text="✅ Mark Attendance", command=self.mark_attendance, bg="#28a745", fg="white", font=("Arial", 12), width=20).grid(row=0, column=0, padx=10)
        Button(btn_frame, text="📄 View Attendance Log", command=self.view_log, bg="#007bff", fg="white", font=("Arial", 12), width=20).grid(row=0, column=1, padx=10)

        # Table area
        self.table_frame = Frame(root, bg="#eaf6ff")
        self.table_frame.pack(pady=10)

    def mark_attendance(self):
        usn = self.usn_entry.get().strip()
        name = self.name_entry.get().strip()
        status = self.status_var.get().strip()
        date = datetime.now().strftime("%Y-%m-%d")
        time = datetime.now().strftime("%H:%M:%S")

        if not usn or not name or not status:
            messagebox.showerror("Input Error", "Please fill all fields.")
            return

        with open(FILENAME, "a", newline="") as file:
            writer = csv.writer(file)
            writer.writerow([usn, name, date, time, status])

        messagebox.showinfo("Success", f"Attendance marked for {name}.")
        self.usn_entry.delete(0, END)
        self.name_entry.delete(0, END)
        self.status_combo.set("")
        self.clear_table()

    def view_log(self):
        self.clear_table()

        with open(FILENAME, "r") as file:
            reader = csv.reader(file)
            rows = list(reader)

        if len(rows) <= 1:
            Label(self.table_frame, text="No attendance records found.", bg="#eaf6ff", font=("Arial", 12, "italic")).pack()
            return

        columns = rows[0]
        tree = ttk.Treeview(self.table_frame, columns=columns, show="headings", height=8)
        tree.pack()

        for col in columns:
            tree.heading(col, text=col)
            tree.column(col, anchor="center", width=100)

        for row in rows[1:]:
            tree.insert("", END, values=row)

    def clear_table(self):
        for widget in self.table_frame.winfo_children():
            widget.destroy()

if __name__ == "__main__":
    root = Tk()
    app = AttendanceApp(root)
    root.mainloop()
